---
name: Pro-Pitch Logistics
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#43474e'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#476083'
  primary: '#000613'
  on-primary: '#ffffff'
  primary-container: '#001f3f'
  on-primary-container: '#6f88ad'
  inverse-primary: '#afc8f0'
  secondary: '#795900'
  on-secondary: '#ffffff'
  secondary-container: '#ffbf00'
  on-secondary-container: '#6d5000'
  tertiary: '#110200'
  on-tertiary: '#ffffff'
  tertiary-container: '#391303'
  on-tertiary-container: '#b5785f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#afc8f0'
  on-primary-fixed: '#001c3a'
  on-primary-fixed-variant: '#2f486a'
  secondary-fixed: '#ffdfa0'
  secondary-fixed-dim: '#fbbc00'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#fdb69a'
  on-tertiary-fixed: '#351002'
  on-tertiary-fixed-variant: '#6b3a25'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

The design system is engineered to bridge the gap between high-performance athletic energy and the administrative precision required for facility management. The aesthetic is **Corporate / Modern**, prioritizing clarity, speed of interaction, and institutional trust. 

The target audience—ranging from team captains organizing a weekly match to facility managers overseeing multiple venues—requires an interface that feels dependable and organized. The UI evokes a "stadium under lights" atmosphere: professional, vast, and ready for action. By utilizing a card-based architecture with significant whitespace, the system ensures that complex scheduling data remains legible and stress-free.

## Colors

The palette is anchored by **Navy Blue (#001F3F)**, used for primary navigation, headers, and core branding elements to establish a foundation of stability and authority. **Amber (#FFBF00)** serves as the high-visibility action color, reserved exclusively for primary Calls to Action (CTAs), urgent notifications, and "Book Now" triggers.

A range of cool grays provides the necessary scaffolding for the card-based layout, ensuring that the Navy and Amber elements pop against a clean, neutral background. Success and Error states are clearly defined to provide immediate feedback during the booking flow.

## Typography

This design system utilizes **Inter** across all levels to maintain a systematic, utilitarian, and modern feel. Its high x-height and neutral character make it ideal for data-dense environments like booking calendars and pricing tables.

- **Headlines:** Use Bold and Extra Bold weights (700-800) to create a clear hierarchy.
- **Body:** Regular weight (400) is used for descriptions and facility details to ensure maximum readability.
- **Labels:** Semi-bold (600) and small caps are used for metadata like pitch dimensions, surface types, and time slots.

## Layout & Spacing

The system follows a **Fixed Grid** model for desktop management dashboards to ensure data consistency, while transitioning to a **Fluid Grid** for the mobile booking experience. 

- **Grid:** A 12-column grid is standard for desktop, allowing for a side-bar navigation (2-3 columns) and a main content area (9-10 columns).
- **Rhythm:** An 8px linear scale governs all padding and margins. 
- **Responsive Behavior:** On mobile, margins reduce to 16px, and card components stack vertically. Heavy use of horizontal scrolling is permitted specifically for "Time Slot" selectors to keep the vertical height of the booking interface manageable.

## Elevation & Depth

Visual hierarchy is achieved through a combination of **Tonal Layers** and **Ambient Shadows**. The background is kept at a light neutral (#F8F9FA), while the "Work Surface" (the cards) is pure white.

- **Low Elevation:** Used for inactive cards or pitch listings in a list view. Uses a 1px border (#E9ECEF) with no shadow.
- **Medium Elevation:** Used for active cards and hover states. Features a soft, diffused shadow (0px 4px 20px rgba(0, 31, 63, 0.08)).
- **High Elevation:** Reserved for modals and booking confirmation overlays. Features a more pronounced shadow with a slight Navy tint to maintain brand consistency.

## Shapes

The shape language is defined by **Rounded (12px)** corners. This radius is applied to all primary containers, including pitch cards, booking modals, and image carousels.

- **Base Radius:** 0.5rem (8px) for small components like input fields and tags.
- **Container Radius:** 0.75rem (12px) for cards and main UI containers.
- **Interactive Radius:** 0.5rem (8px) for buttons to maintain a precise, professional look.

Sharp corners (0px) are avoided entirely to maintain a modern and approachable feel, while full "pill" shapes are reserved only for status indicators (e.g., "Available", "Booked").

## Components

### Buttons
- **Primary:** Navy Blue background with white text for standard navigation.
- **Action (CTA):** Amber background with Navy Blue text for the "Book Now" or "Confirm" buttons.
- **Secondary:** Transparent with a Navy Blue 2px border.

### Pitch Cards
Cards are the primary vehicle for information. They must include a high-resolution image with a 12px top-corner radius, followed by a content area containing the pitch title (Headline-sm), a price badge in the top-right, and a grid of labels for "Surface," "Size," and "Lighting."

### Booking Slots
Time slots are represented as small, rounded rectangles. 
- **Available:** White background with Navy border.
- **Selected:** Navy Blue background with white text.
- **Occupied:** Light gray background with strikethrough text and disabled interaction.

### Inputs & Selectors
Form fields use a 1px border that thickens to 2px Navy Blue on focus. Labels should always be visible above the input field (Label-sm) to ensure accessibility for managers multitasking in high-pressure environments.

### Progress Indicators
For multi-step bookings, use a horizontal stepper at the top of the card, utilizing Navy for completed steps and Amber for the current active step.